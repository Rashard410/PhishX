# PhishX-New-Fix
New Fixes for the PHISHX Phishing Tool

Download The Phishx From 
https://github.com/WeebSec/PhishX.git


===========================================================================================

if anyone wants to contribute this opensource code .. then please you are free to use this code ..

============================================================================================
 Install the phishx 
chnge the "data" folder present in the PHISSHX directory And Replace the older "PHISHX.py"  with  new "PHISHX.PY" file
============================================================================================

Just UNZIP the data.zip file and change the smtp server first by making an account from SMTP2GO or SENDERGRID .................


=========================================



